package com.dicoding.mushroom.Navigation

data class BottomBarItem(
    val icon: Int,
    val selectedIcon: Int,
    val screen: Screen
)